#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
printf(1, "readcount systemcall called!! %dth\n",getreadcount());
exit();
}
